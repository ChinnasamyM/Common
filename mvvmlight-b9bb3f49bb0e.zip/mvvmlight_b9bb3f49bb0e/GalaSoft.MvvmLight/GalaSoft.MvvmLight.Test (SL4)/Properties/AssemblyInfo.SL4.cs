﻿using System.Runtime.InteropServices;

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("753CA747-E475-4D93-ABE4-A9658976A8F4")]

﻿using System.Runtime.InteropServices;

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("46ea6e54-595f-41f1-86fb-4ca3df70aa87")]

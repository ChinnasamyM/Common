﻿using System.Runtime.InteropServices;

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("1689bd3a-9a04-49e5-ab10-bb194baef64a")]

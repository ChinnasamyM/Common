﻿namespace GalaSoft.MvvmLight.Test.Stubs
{
    public interface ITestClass
    {
    }
}
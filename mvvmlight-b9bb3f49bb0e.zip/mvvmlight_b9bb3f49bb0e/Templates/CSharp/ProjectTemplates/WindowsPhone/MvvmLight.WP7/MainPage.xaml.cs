﻿using Microsoft.Phone.Controls;

namespace $safeprojectname$
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
